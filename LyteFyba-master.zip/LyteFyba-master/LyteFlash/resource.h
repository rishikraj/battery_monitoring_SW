//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by LyteFlash.rc
//
#define ID_REFRESH                      3
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_LyteFlashTYPE               129
#define IDD_DLG_SELPORT                 129
#define IDD_PROGRESS                    130
#define IDC_LIST_PORTS                  1000
#define IDC_PROGRESS                    1001
#define ID_SEND                         32771
#define ID_SETSERIAL                    32772
#define ID_FILE_SETPORT                 32773
#define ID_SETPORT                      32774
#define ID_FILE_SAVEAS                  32775
#define ID_FILE_RELOADPORTS             32776
#define ID_RELOAD                       32777
#define ID_ADVANCED_PASSWORD            32778
#define ID_ADVANCED_IMAGE               32779
#define ID_PASSWORD_BMU1                32780
#define ID_PASSWORD_BMU2                32781
#define ID_IMAGE_ALL                    32782
#define ID_IMAGE_PROGRAM_4K             32783
#define ID_IMAGE_BSL2                   32784
#define ID_PASSWORD_BSL1                32785
#define ID_PASSWORD_BSL2                32786
#define ID_IMAGE_ALL32787               32787
#define ID_IMAGE_BSL1                   32788
#define ID_IMAGE_ALL2                   32789
#define ID_IMAGE_ALL1                   32790
#define ID_IMAGE_PROGRAM_8K             32791
#define ID_IMAGE_BADSUM                 32792
#define ID_FILE_LONGLONGLONBGLONGNAMEOFMENUITEMITEMITEMITEMITEM 32793
#define ID_PASSWORD_TRUNK               32794
#define ID_PASSWORD_REV61               32795

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
